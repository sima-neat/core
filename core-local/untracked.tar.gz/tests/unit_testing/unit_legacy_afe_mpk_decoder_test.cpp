#define SIMA_NEAT_INTERNAL 1
#include "pipeline/internal/sima/MlaElfIoTopology.h"
#include "pipeline/internal/sima/static_contract/FrameSlotArenaPlan.h"
#include "pipeline/internal/sima/static_contract/KernelRegistry.h"
#include "pipeline/internal/sima/static_contract/LegacyAfeMpkDecoder.h"

#include <cstdlib>
#include <iostream>
#include <string>

namespace {

using namespace simaai::neat::pipeline_internal::sima;
using namespace simaai::neat::pipeline_internal::sima::static_contract;

void check(const bool condition, const char* message) {
  if (!condition) {
    std::cerr << "FAIL: " << message << "\n";
    std::exit(1);
  }
}

MlaElfIoTopology monolithic_topology(const std::uint64_t ifm_extent = 8U,
                                     const std::uint64_t ofm_extent = 8U) {
  MlaElfIoTopology topology;
  topology.valid = true;
  topology.monolithic_ifm = true;
  topology.monolithic_ofm = true;
  topology.monolithic_ifm_extent_bytes = ifm_extent;
  topology.monolithic_ofm_extent_bytes = ofm_extent;
  topology.source_path = "synthetic.elf";
  return topology;
}

const std::string& valid_manifest() {
  static const std::string manifest = R"json({
    "name":"synthetic",
    "model_sdk_version":"2.0.0",
    "input_nodes":[{"name":"input","size":16}],
    "plugins":[
      {
        "name":"cast0","sequence":1,"processor":"EV74","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "kernel":"cast_transform","params":{"out_dtype":"bfloat16",
            "input_shapes":[[1,4]],"output_shapes":[[1,4]]}},
        "input_nodes":[{"name":"input","size":16}],
        "output_nodes":[{"name":"cast0","size":8}]
      },
      {
        "name":"MLA_0","sequence":2,"processor":"MLA","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "number_of_quads_to_user":4},
        "input_nodes":[{"name":"cast0","size":8}],
        "output_nodes":[{"name":"mla0","size":8}],
        "resources":{"executable":"synthetic_mla.elf"}
      },
      {
        "name":"cast1","sequence":3,"processor":"EV74","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "kernel":"cast_transform","params":{"out_dtype":"float32",
            "input_shapes":[[1,4]],"output_shapes":[[1,4]]}},
        "input_nodes":[{"name":"mla0","size":8}],
        "output_nodes":[{"name":"decorated/model/output:0","size":16}]
      },
      {
        "name":"publish","sequence":4,"processor":"EV74","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "kernel":"pass_through","params":{}},
        "input_nodes":[{"name":"decorated/model/output:0","size":16}],
        "output_nodes":[{"name":"pass_through_out_0","size":16}]
      }
    ]
  })json";
  return manifest;
}

const std::string& packed_read_manifest() {
  static const std::string manifest = R"json({
    "name":"packed-read-synthetic",
    "model_sdk_version":"2.0.0",
    "input_nodes":[{"name":"input0","size":16},{"name":"input1","size":16}],
    "plugins":[
      {
        "name":"pack","sequence":1,"processor":"EV74","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "kernel":"pack_transform","params":{"input_shapes":[[1,16],[1,16]],
            "output_shapes":[[1,32]]}},
        "input_nodes":[{"name":"input0","size":16},{"name":"input1","size":16}],
        "output_nodes":[{"name":"packed_ifm","size":32}]
      },
      {
        "name":"MLA_0","sequence":2,"processor":"MLA","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "number_of_quads_to_user":4},
        "input_nodes":[{"name":"packed_ifm","size":32}],
        "output_nodes":[{"name":"packed_ofm","size":32}],
        "resources":{"executable":"synthetic_mla.elf"}
      },
      {
        "name":"unpack","sequence":3,"processor":"EV74","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "kernel":"unpack_transform","params":{
            "tensor_types":["int8","int8"],
            "tensor_shapes":[[1,2,2,4],[1,2,2,4]],
            "input_shapes":[[1,32]],
            "output_shapes":[[1,2,2,4],[1,2,2,4]]}},
        "input_nodes":[{"name":"packed_ofm","size":32}],
        "output_nodes":[{"name":"unpacked0","size":16},{"name":"unpacked1","size":16}]
      },
      {
        "name":"slice0","sequence":4,"processor":"EV74","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "kernel":"slice_transform","params":{
            "begin":[0,0,0,0],"end":[1,2,2,1],
            "input_shape":[1,2,2,4],"output_shape":[1,2,2,1],
            "input_shapes":[[1,2,2,4]],"output_shapes":[[1,2,2,1]]}},
        "input_nodes":[{"name":"unpacked0","size":16}],
        "output_nodes":[{"name":"slice0_out","size":4}]
      },
      {
        "name":"slice1","sequence":5,"processor":"EV74","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "kernel":"slice_transform","params":{
            "begin":[0,0,0,1],"end":[1,2,2,2],
            "input_shape":[1,2,2,4],"output_shape":[1,2,2,1],
            "input_shapes":[[1,2,2,4]],"output_shapes":[[1,2,2,1]]}},
        "input_nodes":[{"name":"unpacked1","size":16}],
        "output_nodes":[{"name":"slice1_out","size":4}]
      },
      {
        "name":"publish","sequence":6,"processor":"EV74","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "kernel":"pass_through","params":{}},
        "input_nodes":[{"name":"slice0_out","size":4},{"name":"slice1_out","size":4}],
        "output_nodes":[{"name":"pass_through_out_0","size":4},
          {"name":"pass_through_out_1","size":4}]
      }
    ]
  })json";
  return manifest;
}

const std::string& padded_qmla_output_manifest() {
  static const std::string manifest = R"json({
    "name":"qmla-padded-output",
    "model_sdk_version":"2.0.0",
    "input_nodes":[{"name":"input","size":16,"dtype":"float32","shape":[1,4],"layout":"normal"}],
    "plugins":[
      {
        "name":"MLA_0","sequence":1,"processor":"MLA","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "number_of_quads_to_user":4},
        "input_nodes":[{"name":"input","size":16,"dtype":"float32","shape":[1,4],"layout":"normal"}],
        "output_nodes":[{"name":"logits","size":109200,"dtype":"float32",
          "shape":[1,300,91],"layout":"normal"}],
        "resources":{"executable":"synthetic_mla.elf"}
      },
      {
        "name":"publish","sequence":2,"processor":"EV74","type":"sgpProcess",
        "config_params":{"desired_batch_size":1,"actual_batch_size":1,
          "kernel":"pass_through","params":{}},
        "input_nodes":[{"name":"logits","size":109200,"dtype":"float32",
          "shape":[1,300,91],"layout":"normal"}],
        "output_nodes":[{"name":"public_logits","size":109200,"dtype":"float32",
          "shape":[1,300,91],"layout":"normal"}]
      }
    ]
  })json";
  return manifest;
}

MlaElfIoTopology padded_qmla_topology(const std::uint64_t ofm_extent = 110400U) {
  MlaElfIoTopology topology;
  topology.valid = true;
  topology.ifm_symbol_names = {"data.ifm.persistent.afe_direct_input_0.b0"};
  topology.ifm_extent_bytes = {16U};
  topology.ofm_symbol_names = {"data.ofm.persistent.afe_mla_output_0.b0"};
  topology.ofm_extent_bytes = {ofm_extent};
  topology.source_path = "synthetic-qmla.elf";
  return topology;
}

std::string replace_once(std::string value, const std::string& before, const std::string& after) {
  const auto position = value.find(before);
  check(position != std::string::npos, "test mutation token exists");
  value.replace(position, before.size(), after);
  return value;
}

void expect_error(const std::string& manifest, const MlaElfIoTopology& topology,
                  const LegacyAfeDecodeErrorCode expected, const char* message) {
  const auto result = LegacyAfeMpkDecoder{}.decode_json(manifest, topology, "synthetic.json");
  check(!result, message);
  check(result.error.has_value() && result.error->code == expected, message);
  check(!result.error->json_path.empty() && !result.error->detail.empty(),
        "failure has stable path and detail");
}

void test_exact_registry() {
  const auto legacy = lookup_exact_kernel("2.0.0", "EV74", "cast_transform");
  const auto modern_alias = lookup_exact_kernel("2.0.0", "EV74", "cast");
  check(legacy.has_value() && legacy->kind == OpKind::Cast, "legacy cast token has an exact entry");
  check(modern_alias.has_value() && modern_alias->kind == OpKind::Cast,
        "new cast spelling has its own exact entry");
  check(!lookup_exact_kernel("2.0.0", "EV74", "prefix_cast_transform").has_value(),
        "registry rejects substring matches");
  check(!lookup_exact_kernel("2.0.0", "ev74", "cast_transform").has_value(),
        "registry rejects processor case folding");
  check(!lookup_exact_kernel("2.0.1", "EV74", "cast_transform").has_value(),
        "registry rejects version fallback");
}

void test_success_and_immutable_contract() {
  const auto result =
      LegacyAfeMpkDecoder{}.decode_json(valid_manifest(), monolithic_topology(), "synthetic.json");
  if (!result && result.error.has_value()) {
    std::cerr << result.error->json_path << ": " << result.error->detail << "\n";
  }
  check(static_cast<bool>(result), "valid manifest decodes");
  const auto& plan = *result.plan;
  check(plan.contract_version() == "2.0.0", "contract version preserved exactly");
  check(plan.model_inputs().size() == 1U && plan.model_outputs().size() == 1U,
        "public input/output arity preserved");
  check(plan.ops().size() == 4U && plan.values().size() == 5U,
        "ordered graph and value table materialized once");
  check(plan.model_outputs()[0].name == "pass_through_out_0",
        "terminal full output name preserved");
  check(plan.value(plan.model_outputs()[0].value_id)->logical_dtype == "float32",
        "typed inverse preserves published dtype");
  check(plan.backend_ports().size() == 2U, "monolithic ELF is exactly 1 IFM / 1 OFM");
  for (const auto& port : plan.backend_ports()) {
    check(port.required_alignment_bytes == kLegacyEvoCmaRegionAlignmentBytes,
          "legacy port uses documented conservative alignment");
    check(port.alignment_authority == BackendPortAlignmentAuthority::LegacyPolicy,
          "legacy alignment provenance is policy, not MPK/ELF");
  }
  check(plan.backend_ports()[0].elf_symbol == "data.ifm.b0" &&
            plan.backend_ports()[1].elf_symbol == "data.ofm.b0",
        "exact monolithic symbols retained");
  check(!result.proof.empty(), "deterministic proof report emitted");
}

void test_unpack_and_slice_are_read_expressions() {
  const auto result = LegacyAfeMpkDecoder{}.decode_json(
      packed_read_manifest(), monolithic_topology(32U, 32U), "packed-read-synthetic.json");
  if (!result && result.error.has_value()) {
    std::cerr << result.error->json_path << ": " << result.error->detail << "\n";
  }
  check(static_cast<bool>(result), "packed read-expression manifest decodes");
  const auto& plan = *result.plan;
  check(plan.backend_ports().size() == 2U, "packed route remains one IFM and one OFM");
  check(plan.model_outputs().size() == 2U, "both logical reads are published");
  const auto* pack = std::get_if<PackOpConfig>(&plan.ops().front().config);
  check(pack != nullptr && pack->components.size() == 2U &&
            pack->components[0].parent_offset == 0U &&
            pack->components[0].stored_bytes == 16U &&
            pack->components[1].parent_offset == 16U &&
            pack->components[1].stored_bytes == 16U,
        "Pack carries exact ordered parent placement");

  // Value order is: two public inputs, pack, MLA, two unpack reads, two
  // slice reads, two publication reads.  Every read remains rooted in the
  // single materialized MLA OFM; neither Unpack nor Slice schedules work.
  const auto require_read = [&](const ValueId id, const std::uint64_t offset) {
    const auto* value = plan.value(id);
    check(value != nullptr && value->read_expression.has_value(),
          "logical value carries a compiled read expression");
    check(value->read_expression->source_value_id == 3U,
          "logical read is composed to the physical MLA carrier");
    check(value->read_expression->byte_offset == offset,
          "logical read preserves its exact carrier-relative offset");
    check(value->read_expression->stride_bytes == std::vector<std::int64_t>({16, 8, 4, 1}),
          "logical read preserves the exact inherited byte strides");
  };
  require_read(4U, 0U);
  require_read(5U, 16U);
  require_read(6U, 0U);
  require_read(7U, 17U);
  require_read(8U, 0U);
  require_read(9U, 17U);

  std::size_t read_proofs = 0U;
  for (const auto& fact : result.proof) {
    if (fact.subject.rfind("read[", 0U) == 0U &&
        fact.evidence.find("no runtime operation is scheduled") != std::string::npos) {
      ++read_proofs;
    }
  }
  check(read_proofs == 4U, "decoder proves both unpack and both slice reads are not jobs");
}

void test_qmla_physical_extent_authors_padded_logical_view() {
  const auto result = LegacyAfeMpkDecoder{}.decode_json(
      padded_qmla_output_manifest(), padded_qmla_topology(), "qmla-padded.json");
  if (!result && result.error.has_value()) {
    std::cerr << result.error->json_path << ": " << result.error->detail << "\n";
  }
  check(static_cast<bool>(result), "QMLA padded output manifest decodes");
  const auto& plan = *result.plan;
  check(plan.backend_ports().size() == 2U &&
            plan.backend_ports()[1].physical_extent_bytes == 110400U,
        "ELF owns exact QMLA physical extent");
  const auto* root = plan.value(plan.ops().front().outputs.front());
  const auto* published = plan.value(plan.model_outputs().front().value_id);
  const std::vector<std::int64_t> expected_strides{110400, 368, 4};
  check(root && root->required_bytes == 109200U && root->read_expression.has_value() &&
            root->read_expression->source_value_id == root->id &&
            root->read_expression->stride_bytes == expected_strides,
        "logical logits retain exact row-padded affine storage binding");
  check(published && published->required_bytes == 109200U &&
            published->read_expression.has_value() &&
            published->read_expression->source_value_id == root->id &&
            published->read_expression->stride_bytes == expected_strides,
        "public logits preserve the exact backend-rooted affine view");
  std::string arena_error;
  const auto arena = FrameSlotArenaPlan::compile(
      plan, FrameSlotArenaReuse::DisjointLifetimes,
      kLegacyEvoCmaRegionAlignmentBytes, &arena_error);
  check(arena.has_value(), "QMLA padded output has a valid frame arena");
  const auto* region = arena->region(root->id);
  check(region && region->size_bytes == 110400U,
        "frame arena allocates the complete backend physical carrier");

  expect_error(padded_qmla_output_manifest(), padded_qmla_topology(109199U),
               LegacyAfeDecodeErrorCode::ValueSizeMismatch,
               "ELF physical output smaller than logical tensor fails closed");
  auto missing = padded_qmla_topology();
  missing.ofm_extent_bytes.clear();
  expect_error(padded_qmla_output_manifest(), missing,
               LegacyAfeDecodeErrorCode::ElfTopologyInvalid,
               "missing QMLA output extent fails closed");
}

void test_fail_closed_cases() {
  const auto topology = monolithic_topology();
  expect_error(replace_once(valid_manifest(), "2.0.0", "2.0.1"), topology,
               LegacyAfeDecodeErrorCode::UnsupportedContractVersion,
               "unsupported version fails closed");
  expect_error(replace_once(valid_manifest(), "cast_transform", "cast_transform_suffix"), topology,
               LegacyAfeDecodeErrorCode::UnsupportedKernel, "kernel substring is not an alias");
  expect_error(replace_once(valid_manifest(),
                            "\"name\":\"cast0\",\"size\":8}],\n        \"output_nodes\"",
                            "\"name\":\"missing\",\"size\":8}],\n        \"output_nodes\""),
               topology, LegacyAfeDecodeErrorCode::MissingProducer,
               "missing full-name producer fails closed");
  expect_error(replace_once(valid_manifest(), "\"params\":{\"out_dtype\":\"bfloat16\"",
                            "\"params\":{\"ignored\":1,\"out_dtype\":\"bfloat16\""),
               topology, LegacyAfeDecodeErrorCode::InvalidField,
               "untyped extra operation config is not ignored");

  auto two_ifm = topology;
  two_ifm.monolithic_ifm = false;
  two_ifm.monolithic_ifm_extent_bytes = 0U;
  two_ifm.ifm_symbol_names = {"data.ifm.persistent.qmla_ifm_0.b0",
                              "data.ifm.persistent.qmla_ifm_1.b0"};
  two_ifm.ifm_extent_bytes = {8U, 8U};
  expect_error(valid_manifest(), two_ifm, LegacyAfeDecodeErrorCode::ElfTopologyMismatch,
               "MPK/ELF port arity mismatch fails before plan creation");

  auto conflict = topology;
  conflict.ifm_layout_conflict = true;
  expect_error(valid_manifest(), conflict, LegacyAfeDecodeErrorCode::ElfTopologyInvalid,
               "ambiguous ELF layout fails closed");
}

int validate_explicit_pair(const char* manifest_path, const char* elf_path) {
  MlaElfIoTopology topology;
  if (!read_mla_elf_io_topology(elf_path, &topology)) {
    std::cerr << topology.error << "\n";
    return 2;
  }
  const auto result = LegacyAfeMpkDecoder{}.decode_file(manifest_path, topology);
  if (!result) {
    std::cerr << result.error->json_path << ": " << result.error->detail << "\n";
    return 1;
  }
  std::size_t ifm_count = 0U;
  std::size_t ofm_count = 0U;
  for (const auto& port : result.plan->backend_ports()) {
    if (port.direction == BackendPortDirection::Input) {
      ++ifm_count;
    } else {
      ++ofm_count;
    }
  }
  std::cout << "inputs=" << result.plan->model_inputs().size()
            << " outputs=" << result.plan->model_outputs().size() << " ifm=" << ifm_count
            << " ofm=" << ofm_count << "\n";
  return 0;
}

} // namespace

int main(const int argc, char** argv) {
  if (argc == 3) {
    return validate_explicit_pair(argv[1], argv[2]);
  }
  check(argc == 1, "usage: unit_legacy_afe_mpk_decoder_test [manifest elf]");
  test_exact_registry();
  test_success_and_immutable_contract();
  test_unpack_and_slice_are_read_expressions();
  test_qmla_physical_extent_authors_padded_logical_view();
  test_fail_closed_cases();
  std::cout << "unit_legacy_afe_mpk_decoder_test: PASS\n";
  return 0;
}
